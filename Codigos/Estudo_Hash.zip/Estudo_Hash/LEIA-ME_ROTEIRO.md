# Roteiro de estudo: HashMap (Telefonia + Encurtador)

## Como abrir no NetBeans
Crie um projeto Java novo, copie a pasta `src` de cada projeto para dentro dele e rode:
- Telefonia: `servidor/view/JFrameServidor.java` (tela) ou `servidor/TesteConsole.java` (sem tela)
- Encurtador: `view/EncurtadorView.java` (tela) ou `teste/TesteConsole.java` (sem tela)

## A ideia em 3 linhas
- HashMap guarda pares chave -> valor e busca pela chave em O(1), sem varrer tudo.
- Ele calcula chave.hashCode(), converte em indice de bucket e confere com equals().
- Colisao = chaves diferentes no mesmo bucket (resolvida com lista/arvore dentro do bucket).

## Metodos que voce precisa saber de cor
put(k,v)  get(k)  containsKey(k)  remove(k)  size()  values()  keySet()  clear()
- put em chave existente SUBSTITUI o valor.
- get em chave inexistente devolve null (compare com == null, nunca .isEmpty()).

## Telefonia: o que lembrar
1. chave = numero do celular, valor = objeto Sessao (HashMap<String, Sessao>)
2. carregar: BufferedReader + readLine + split(";", 2) + put
3. pesquisar: sessoes.get(numero)
4. HashMap nao tem ordem -> copia para ArrayList e ordena para a JTable
5. Model extends AbstractTableModel: getRowCount, getColumnCount, getColumnName, getValueAt
6. View -> Controller -> Model (a view nunca fala direto com o model)

## Encurtador: o que lembrar
1. chave = codigo curto, valor = URL original (HashMap<String, String>)
2. codigo = url.hashCode() & 0x7fffffff   (a mascara tira o sinal negativo)
3. encurtar = put(codigo, url) | buscar = split("/"), pegar o ultimo pedaco, get(codigo)
4. Se get devolver null -> "Link encurtado nao encontrado!"
5. Colisao: duas URLs com o mesmo hashCode -> a segunda sobrescreve a primeira (por isso o while com containsKey)

## Ordem para escrever na prova (do zero)
1. Classe do dado (Sessao) ou direto o HashMap (Encurtador)
2. Model com o HashMap + metodo de inserir e de buscar
3. Controller chamando o model
4. View: campos, botoes, addActionListener chamando o controller
5. Testar com um TesteConsole antes de mexer na tela

## Erros classicos para evitar
- get() devolve null e voce chama .isEmpty()/.equals() nele -> NullPointerException
- return antes do if (o if nunca executa)
- parametro com um nome e corpo usando outro
- esquecer fireTableDataChanged() depois de mudar os dados da tabela
- new Controller().setVisible(true) em vez de new View().setVisible(true)
