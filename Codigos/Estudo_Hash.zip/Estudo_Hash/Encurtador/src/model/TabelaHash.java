package model;

import java.util.HashMap;

/**
 * MODEL: guarda os links em um HashMap.
 *
 *   chave  = codigo curto (ex: "1234567890")      -> String
 *   valor  = URL original (ex: "https://www.google.com") -> String
 *
 * Por isso o tipo e HashMap<String, String>.
 */
public class TabelaHash {
    public HashMap<String, String> links;

    public TabelaHash() {
        links = new HashMap<>();   // comeca vazio
    }
}
