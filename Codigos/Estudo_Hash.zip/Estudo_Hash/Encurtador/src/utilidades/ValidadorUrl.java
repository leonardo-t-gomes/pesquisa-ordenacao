package utilidades;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * Classe utilitaria: so tem um metodo static que diz se um texto e uma URL valida.
 * Cada teste que falha ja devolve false ("falhou cedo").
 */
public class ValidadorUrl {

    /**
     * @param urlString texto digitado pelo usuario
     * @return true se for uma URL http/https bem formada, com dominio
     */
    public static boolean isLinkValido(String urlString) {
        // 0) null ou so espacos: invalida
        if (urlString == null || urlString.trim().isEmpty()) {
            return false;
        }

        try {
            // 1) URI valida a SINTAXE (lanca URISyntaxException se tiver espaco, caractere ilegal...)
            URI uri = new URI(urlString);

            // 2) Converte para URL (lanca MalformedURLException se nao tiver protocolo conhecido)
            URL url = uri.toURL();

            // 3) So aceita http e https (ignora maiusculas/minusculas)
            String protocolo = url.getProtocol();
            if (!"http".equalsIgnoreCase(protocolo) && !"https".equalsIgnoreCase(protocolo)) {
                return false;
            }

            // 4) Precisa ter dominio (evita "http://" sozinho)
            String host = url.getHost();
            return host != null && !host.trim().isEmpty();

        } catch (URISyntaxException | MalformedURLException | IllegalArgumentException e) {
            // qualquer erro de formato = invalida
            return false;
        }
    }
}
