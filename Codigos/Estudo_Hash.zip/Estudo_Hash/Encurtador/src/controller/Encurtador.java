package controller;

import model.TabelaHash;

/**
 * CONTROLLER: a logica do encurtador. Metodos static: nao precisa dar "new Encurtador()".
 *
 * Fluxo:
 *   encurtar(url)      -> calcula codigo a partir da URL -> put(codigo, url) -> devolve link curto
 *   buscarLink(curto)  -> extrai o codigo do link curto  -> get(codigo)       -> devolve url original
 */
public class Encurtador {

    /**
     * Gera o link curto e guarda no HashMap.
     */
    public static String encurtar(String linkOriginal, TabelaHash tabela) {
        String DOMINIO = "localhost";

        // 1) String.hashCode() transforma a URL em um numero inteiro (pode ser NEGATIVO).
        // 2) "& 0x7fffffff" zera o bit de sinal: o numero fica sempre POSITIVO.
        int h = linkOriginal.hashCode() & 0x7fffffff;
        String hashGerado = "" + h;          // "" + numero = converte para String

        // 3) COLISAO: duas URLs diferentes podem ter o mesmo hashCode.
        //    Se o codigo ja existe E guarda OUTRA url, soma 1 ate achar um codigo livre.
        //    (Se for a MESMA url, o laco nao roda: reaproveita o mesmo codigo.)
        //    Versao simples de aula, sem tratar colisao, seria apenas:
        //        tabela.links.put(hashGerado, linkOriginal);
        while (tabela.links.containsKey(hashGerado)
                && !tabela.links.get(hashGerado).equals(linkOriginal)) {
            h++;
            hashGerado = "" + h;
        }

        // 4) PUT: guarda  codigo -> url original
        tabela.links.put(hashGerado, linkOriginal);

        // 5) Monta o link curto que o usuario vai ver
        return "https://" + DOMINIO + "/" + hashGerado;
    }

    /**
     * Recebe o link curto e devolve a URL original (ou uma mensagem de erro).
     *
     * ERROS do codigo original (que nao compilava) e como ficaram corrigidos:
     *  - a variavel 'resposta' nao estava declarada
     *  - o parametro chamava 'tabelaHash' mas o corpo usava 'tabela'
     *  - o 'return' vinha ANTES do if (o if nunca executava)
     *  - get() devolve null quando nao acha; null.isEmpty() da NullPointerException
     */
    public static String buscarLinkEncurtado(String linkEncurtado, TabelaHash tabelaHash) {
        // "https://localhost/123456".split("/") -> ["https:", "", "localhost", "123456"]
        String[] dadosLink = linkEncurtado.split("/");

        // O codigo e sempre o ULTIMO pedaco
        String hashObtido = dadosLink[dadosLink.length - 1];

        // GET: busca no HashMap. Se nao existir, devolve null (nao da erro).
        String resposta = tabelaHash.links.get(hashObtido);

        // Compara com null (nao com isEmpty!)
        if (resposta == null) {
            resposta = "Link encurtado não encontrado!";
        }
        return resposta;
    }
}
