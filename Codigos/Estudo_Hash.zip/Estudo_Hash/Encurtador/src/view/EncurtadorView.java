package view;

import controller.Encurtador;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.net.URI;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.TabelaHash;
import utilidades.ValidadorUrl;

/**
 * VIEW. No NetBeans voce monta isso ARRASTANDO componentes (arquivo .form) e o
 * NetBeans gera o initComponents(). Aqui o layout foi escrito a mao so para o
 * arquivo ficar completo e compilavel; a LOGICA dos botoes e a mesma da aula.
 *
 * Os nomes (jTextField_linkOriginal etc.) sao os mesmos que o NetBeans gerou.
 */
public class EncurtadorView extends JFrame {

    // O "banco de dados" em memoria: vive enquanto a janela estiver aberta
    private TabelaHash meusLinks;

    private JTextField jTextField_linkOriginal = new JTextField(30);
    private JTextField jTextField_linkEncurtado = new JTextField(30);
    private JButton jButton_gerarLinkEncurtado = new JButton("Gerar link encurtado");
    private JButton jButton_testarLocal = new JButton("Testar local");
    private JButton jButton_testarWeb = new JButton("Testar web");   // era jButton_gerarLinkEncurtado1
    private JButton jButton_limpar = new JButton("Limpar");

    public EncurtadorView() {
        initComponents();
        meusLinks = new TabelaHash();        // cria o HashMap vazio
    }

    private void initComponents() {
        setTitle("Encurtador de links");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        jTextField_linkEncurtado.setEditable(false);   // so mostra, usuario nao digita

        JPanel campos = new JPanel(new GridLayout(3, 2, 8, 8));
        campos.setBorder(BorderFactory.createEmptyBorder(12, 12, 6, 12));
        campos.add(new JLabel("Link original"));
        campos.add(jTextField_linkOriginal);
        campos.add(new JLabel(""));
        campos.add(jButton_gerarLinkEncurtado);
        campos.add(new JLabel("Link encurtado"));
        campos.add(jTextField_linkEncurtado);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 8));
        botoes.add(jButton_limpar);
        botoes.add(jButton_testarLocal);
        botoes.add(jButton_testarWeb);

        add(campos, BorderLayout.CENTER);
        add(botoes, BorderLayout.SOUTH);

        // Liga cada botao ao seu metodo (this::metodo = "chame este metodo quando clicar")
        jButton_gerarLinkEncurtado.addActionListener(this::jButton_gerarLinkEncurtadoActionPerformed);
        jButton_testarLocal.addActionListener(this::jButton_testarLocalActionPerformed);
        jButton_testarWeb.addActionListener(this::jButton_testarWebActionPerformed);
        jButton_limpar.addActionListener(this::jButton_limparActionPerformed);

        pack();
        setLocationRelativeTo(null);
    }

    /** GERAR: valida a URL, encurta e mostra o link curto. */
    private void jButton_gerarLinkEncurtadoActionPerformed(ActionEvent evt) {
        String urlStr = jTextField_linkOriginal.getText();

        // Vazia OU invalida: avisa e PARA (return)
        if (urlStr.isEmpty() || !ValidadorUrl.isLinkValido(urlStr)) {
            JOptionPane.showMessageDialog(this, "Verifique link informado", "Atenção",
                    JOptionPane.WARNING_MESSAGE);   // (o original usava HEIGHT por engano)
            return;
        }

        // Controller faz o trabalho (hashCode + put) e devolve o link curto
        jTextField_linkEncurtado.setText(Encurtador.encurtar(urlStr, meusLinks));
    }

    /** TESTAR LOCAL: usa o HashMap para voltar do link curto ao original. */
    private void jButton_testarLocalActionPerformed(ActionEvent evt) {
        String urlStr = jTextField_linkEncurtado.getText();
        if (!urlStr.isEmpty()) {
            String urlOriginal = Encurtador.buscarLinkEncurtado(urlStr, meusLinks);
            JOptionPane.showMessageDialog(this, urlOriginal);
        }
    }

    /** TESTAR WEB: abre o link no navegador. */
    private void jButton_testarWebActionPerformed(ActionEvent evt) {
        String urlStr = jTextField_linkEncurtado.getText();
        if (!urlStr.isEmpty()) {
            try {
                // Se o usuario digitou so "google.com", acrescenta https://
                if (!urlStr.startsWith("http://") && !urlStr.startsWith("https://")) {
                    urlStr = "https://" + urlStr;
                }
                // CORRECAO: no original o browse() ficava DENTRO deste if, entao links que
                // ja comecavam com https:// nunca abriam. Agora fica fora.
                Desktop.getDesktop().browse(new URI(urlStr));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Não foi possível abrir o link.");
            }
        }
    }

    /** LIMPAR: esvazia os dois campos. */
    private void jButton_limparActionPerformed(ActionEvent evt) {
        jTextField_linkEncurtado.setText("");
        jTextField_linkOriginal.setText("");
    }

    public static void main(String[] args) {
        // CORRECAO: o original fazia new Encurtador() (o controller). A janela e EncurtadorView.
        java.awt.EventQueue.invokeLater(() -> new EncurtadorView().setVisible(true));
    }
}
