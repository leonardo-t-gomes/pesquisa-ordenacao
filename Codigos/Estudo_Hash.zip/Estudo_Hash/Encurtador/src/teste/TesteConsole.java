package teste;

import controller.Encurtador;
import model.TabelaHash;
import utilidades.ValidadorUrl;

/**
 * Teste SEM tela: roda no console. Otimo para entender o HashMap sem Swing.
 * Execute esta classe (Run File no NetBeans) e leia a saida.
 */
public class TesteConsole {
    public static void main(String[] args) {
        TabelaHash tabela = new TabelaHash();

        // 1) Encurtar
        String curto = Encurtador.encurtar("https://www.google.com", tabela);
        System.out.println("Link curto: " + curto);

        // 2) Voltar ao original
        System.out.println("Original:   " + Encurtador.buscarLinkEncurtado(curto, tabela));

        // 3) Link que nao existe
        System.out.println("Inexistente: " + Encurtador.buscarLinkEncurtado("https://localhost/999", tabela));

        // 4) Mesma URL duas vezes: nao cria entrada nova (put substitui a mesma chave)
        Encurtador.encurtar("https://www.google.com", tabela);
        System.out.println("Tamanho do mapa (esperado 1): " + tabela.links.size());

        // 5) Colisao REAL: "Aa" e "BB" tem o mesmo hashCode (2112)
        System.out.println("hashCode Aa=" + "Aa".hashCode() + "  BB=" + "BB".hashCode());
        String c1 = Encurtador.encurtar("Aa", tabela);
        String c2 = Encurtador.encurtar("BB", tabela);
        System.out.println("Aa -> " + c1);
        System.out.println("BB -> " + c2 + "  (codigos diferentes: colisao tratada)");
        System.out.println("Volta Aa: " + Encurtador.buscarLinkEncurtado(c1, tabela));
        System.out.println("Volta BB: " + Encurtador.buscarLinkEncurtado(c2, tabela));

        // 6) Validador
        System.out.println(ValidadorUrl.isLinkValido("https://www.google.com")); // true
        System.out.println(ValidadorUrl.isLinkValido("google.com"));              // false
        System.out.println(ValidadorUrl.isLinkValido("ftp://x.com"));             // false
        System.out.println(ValidadorUrl.isLinkValido("http://"));                 // false
    }
}
