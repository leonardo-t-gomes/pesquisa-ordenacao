package servidor.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;
import servidor.controller.ServidorController;
import servidor.model.Sessao;
import servidor.model.TabelaHash;

/**
 * VIEW (o "V" do MVC): so cuida da tela. Nada de regra de negocio aqui.
 * Layout: topo (arquivo) / centro (tabela) / baixo (consulta + status).
 */
public class JFrameServidor extends JFrame {

    // A view conhece o controller (nunca o contrario)
    private final ServidorController controller = new ServidorController();

    private final JTextField txtArquivo = new JTextField(40);
    private final JButton btnCarregar = new JButton("Carregar");

    // JTable ligada ao model: ela pergunta ao model o que mostrar em cada celula
    private final JTable tabela = new JTable(controller.getTabela());

    // Sorter: permite ordenar clicando no titulo e FILTRAR linhas
    private final TableRowSorter<TabelaHash> sorter = new TableRowSorter<>(controller.getTabela());

    private final JTextField txtNumero = new JTextField(16);
    private final JButton btnConsultar = new JButton("Consultar");
    private final JLabel lblStatus = new JLabel("Nenhum arquivo carregado.");

    public JFrameServidor() {
        setTitle("Servidor de Sessoes em Telefonia");
        setDefaultCloseOperation(EXIT_ON_CLOSE);          // fechar a janela encerra o programa

        // Painel principal com BorderLayout (NORTH, CENTER, SOUTH...)
        JPanel raiz = new JPanel(new BorderLayout(8, 8));
        raiz.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // margem
        setContentPane(raiz);

        // ---- TOPO: caminho do arquivo + botao Carregar ----
        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        topo.add(new JLabel("Arquivo da base de dados:"));
        topo.add(txtArquivo);
        topo.add(btnCarregar);
        add(topo, BorderLayout.NORTH);

        // ---- CENTRO: tabela com barra de rolagem ----
        tabela.setRowSorter(sorter);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);   // permite rolagem horizontal
        for (int i = 0; i < tabela.getColumnCount(); i++) {
            // largura de cada coluna: a 0 (numero) 120, a 1 (session_id) 280, resto 130
            tabela.getColumnModel().getColumn(i).setPreferredWidth(i == 0 ? 120 : (i == 1 ? 280 : 130));
        }
        JScrollPane rolagem = new JScrollPane(tabela);      // sem isso nao aparece cabecalho/rolagem
        rolagem.setPreferredSize(new Dimension(900, 400));
        add(rolagem, BorderLayout.CENTER);

        // ---- BAIXO: consulta + mensagem de status ----
        JPanel sul = new JPanel(new BorderLayout(0, 6));
        JPanel consulta = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        consulta.add(new JLabel("Numero do celular:"));
        consulta.add(txtNumero);
        consulta.add(btnConsultar);
        sul.add(consulta, BorderLayout.NORTH);
        sul.add(lblStatus, BorderLayout.SOUTH);
        add(sul, BorderLayout.SOUTH);

        // ---- EVENTOS: ligam cada botao a um metodo ----
        // e -> carregar()  e uma expressao lambda: "quando acontecer, chame carregar()"
        btnCarregar.addActionListener(e -> carregar());
        txtArquivo.addActionListener(e -> carregar());      // ENTER no campo tambem carrega
        btnConsultar.addActionListener(e -> consultar());
        txtNumero.addActionListener(e -> consultar());      // ENTER no campo tambem consulta

        pack();                          // ajusta a janela ao tamanho dos componentes
        setLocationRelativeTo(null);     // centraliza na tela
    }

    /** Acao do botao Carregar. */
    private void carregar() {
        String arquivo = txtArquivo.getText().trim();
        if (arquivo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Digite o caminho completo do arquivo.");
            return;                                   // para aqui
        }
        sorter.setRowFilter(null);                    // tira filtro de consulta anterior

        if (controller.carregarArquivo(arquivo)) {
            lblStatus.setText(controller.totalSessoes() + " sessoes carregadas.");
        } else {
            lblStatus.setText("Falha ao carregar o arquivo.");
            JOptionPane.showMessageDialog(this, "Arquivo nao localizado ou com problemas");
        }
    }

    /** Acao do botao Consultar: filtra a tabela para mostrar so o numero digitado. */
    private void consultar() {
        // final: a classe anonima la embaixo so pode usar variaveis que nao mudam
        final String numero = txtNumero.getText().trim();

        if (numero.isEmpty()) {                       // campo vazio = mostra tudo
            sorter.setRowFilter(null);
            lblStatus.setText("Exibindo todas as " + controller.totalSessoes() + " sessoes.");
            return;
        }

        // 1) BUSCA NO HASHMAP: so para saber SE EXISTE (decide a mensagem)
        Sessao sessao = controller.pesquisar(numero);

        // 2) FILTRO VISUAL: esconde as linhas cujo numero (coluna 0) e diferente
        sorter.setRowFilter(new RowFilter<TabelaHash, Integer>() {
            @Override
            public boolean include(Entry<? extends TabelaHash, ? extends Integer> linha) {
                return numero.equals(linha.getStringValue(0));   // true = linha aparece
            }
        });

        lblStatus.setText(sessao == null
                ? "Numero " + numero + " nao encontrado."
                : "Numero " + numero + " encontrado.");
    }

    // main: ponto de entrada do programa
    public static void main(String[] args) {
        try {
            // Tenta usar o visual "Nimbus"; se nao existir, usa o padrao
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrameServidor.class.getName())
                    .log(java.util.logging.Level.SEVERE, null, ex);
        }
        // invokeLater: cria a janela na thread correta do Swing
        java.awt.EventQueue.invokeLater(() -> new JFrameServidor().setVisible(true));
    }
}
