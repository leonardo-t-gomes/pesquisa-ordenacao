package servidor.controller;

import servidor.model.Sessao;
import servidor.model.TabelaHash;

/**
 * CONTROLLER (o "C" do MVC): fica no meio entre a tela e o model.
 * A tela NAO fala direto com o model: ela pede ao controller.
 */
public class ServidorController {

    // O controller e quem cria e possui o model
    private final TabelaHash tabela = new TabelaHash();

    /** Entrega o model para a view ligar a JTable nele. */
    public TabelaHash getTabela() {
        return tabela;
    }

    /** Manda o model carregar o arquivo. true = deu certo. */
    public boolean carregarArquivo(String nomeArquivo) {
        return tabela.carregar(nomeArquivo);
    }

    /** Quantas sessoes tem no HashMap. */
    public int totalSessoes() {
        return tabela.sessoes.size();
    }

    /** Busca no HashMap. trim() tira espacos que o usuario digitou sem querer. */
    public Sessao pesquisar(String numeroCelular) {
        return tabela.pesquisar(numeroCelular.trim());
    }
}
