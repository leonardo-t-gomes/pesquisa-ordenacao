package servidor.model;

/**
 * SESSAO = o "valor" que fica guardado dentro do HashMap.
 *
 * Cada linha do arquivo vira um objeto Sessao:
 *   5592914942603;{"session_id": "...", "imsi": "...", ...}
 *   \___________/ \_______________________________/
 *    numeroCelular            dadosSessao
 *
 * IDEIA: o numero do celular e a CHAVE de busca (identifica a sessao).
 * O JSON inteiro fica guardado como texto, sem separar campo por campo.
 */
public class Sessao {
    public String numeroCelular;   // chave de busca (ex: "5592914942603")
    public String dadosSessao;     // JSON completo, como texto

    // Construtor: recebe os dois pedacos e guarda nos atributos
    public Sessao(String numeroCelular, String dadosSessao) {
        this.numeroCelular = numeroCelular;
        this.dadosSessao = dadosSessao;
    }

    // toString: como o objeto aparece quando fazemos System.out.println(sessao)
    @Override
    public String toString() {
        return "Sessao [numeroCelular=" + numeroCelular + ", dadosSessao=" + dadosSessao + "]";
    }

    /**
     * hashCode: transforma o objeto em um numero inteiro.
     * Aqui o hash depende SO do numeroCelular (mesma regra do equals abaixo).
     *
     * REGRA DE OURO: se dois objetos sao equals(), TEM que ter o mesmo hashCode().
     * (O contrario nao precisa valer: hashes iguais com objetos diferentes = colisao.)
     *
     * O 31 e um numero primo tradicional: ajuda a espalhar bem os valores.
     * Obs: neste projeto a CHAVE do HashMap e uma String (que ja tem hashCode pronto),
     * entao este metodo so seria usado se Sessao fosse CHAVE ou entrasse num HashSet.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((numeroCelular == null) ? 0 : numeroCelular.hashCode());
        return result;
    }

    /**
     * equals: define quando duas Sessoes sao "a mesma".
     * Aqui: mesmo numeroCelular = mesma sessao.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)                      // e o proprio objeto? entao e igual
            return true;
        if (obj == null)                      // comparar com null: nunca e igual
            return false;
        if (getClass() != obj.getClass())     // classes diferentes: nao e igual
            return false;
        Sessao other = (Sessao) obj;          // agora e seguro converter
        if (numeroCelular == null) {
            if (other.numeroCelular != null)
                return false;
        } else if (!numeroCelular.equals(other.numeroCelular))
            return false;
        return true;                          // passou em tudo: sao iguais
    }
}
