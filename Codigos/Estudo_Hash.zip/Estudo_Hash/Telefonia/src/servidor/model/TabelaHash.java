package servidor.model;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.AbstractTableModel;

/**
 * MODEL (o "M" do MVC).
 *
 * Esta classe faz DUAS coisas:
 *   1) Guarda as sessoes em um HashMap (chave = numero do celular)  -> BUSCA RAPIDA
 *   2) Serve de modelo de dados para a JTable da tela (extends AbstractTableModel)
 *
 * Por que as duas? O HashMap e otimo para BUSCAR, mas nao tem ordem nem
 * "linha 0, linha 1...". A JTable precisa de linhas numeradas. Entao:
 *      HashMap   -> para pesquisar
 *      ArrayList -> para mostrar na tabela
 */
public class TabelaHash extends AbstractTableModel {

    // HashMap<TipoDaChave, TipoDoValor>
    // Chave: numero do celular (String). Valor: objeto Sessao.
    public HashMap<String, Sessao> sessoes = new HashMap<>();

    // Copia ordenada dos valores do HashMap, so para exibir na tabela.
    private List<Sessao> linhas = new ArrayList<>();

    // Nomes dos campos do JSON. Cada um vira uma coluna da tabela.
    private static final String[] CAMPOS = {
        "session_id", "imsi", "imei", "mcc", "mnc", "cell_id", "lac", "bearer",
        "start_time", "end_time", "duration_s", "ip_addr", "sip_call_id", "codec",
        "bytes_up", "bytes_down", "lat", "lon", "encryption"
    };

    // Uma expressao regular (regex) para cada campo, para extrair o valor do JSON.
    // Ex.: para "bearer", a regex acha  "bearer": "3G"  e captura  3G
    private static final Pattern[] PADROES = new Pattern[CAMPOS.length];
    static {   // bloco static: roda uma unica vez, quando a classe e carregada
        for (int i = 0; i < CAMPOS.length; i++) {
            PADROES[i] = Pattern.compile("\"" + CAMPOS[i] + "\"\\s*:\\s*\"?([^\",}]*)\"?");
        }
    }

    /**
     * Le o arquivo (uma sessao por linha, formato  numeroCelular;dadosSessao),
     * cria um objeto Sessao por linha e coloca no HashMap.
     *
     * @return true se leu tudo; false se o arquivo nao existe ou tem linha invalida
     */
    public boolean carregar(String nomeArquivo) {
        sessoes.clear();          // esvazia o mapa (nao misturar com carga anterior)
        boolean ok = true;

        // try-with-resources: o arquivo e fechado automaticamente no fim do bloco
        try (BufferedReader leitor = Files.newBufferedReader(
                Paths.get(nomeArquivo), StandardCharsets.UTF_8)) {

            String linha;
            // Le uma linha por vez ate acabar o arquivo (readLine devolve null no fim)
            while ((linha = leitor.readLine()) != null) {
                if (linha.isBlank()) {
                    continue;                       // pula linha em branco
                }

                // split(";", 2): corta SO no primeiro ';' (o JSON pode ter outros ';')
                //   partes[0] = numero do celular
                //   partes[1] = JSON
                String[] partes = linha.split(";", 2);
                if (partes.length < 2) {            // linha sem ';' = arquivo invalido
                    ok = false;
                    break;
                }

                Sessao sessao = new Sessao(partes[0].trim(), partes[1].trim());

                // PUT: insere no HashMap. Se a chave ja existir, SUBSTITUI o valor.
                sessoes.put(sessao.numeroCelular, sessao);
            }
        } catch (IOException | RuntimeException e) {
            ok = false;            // arquivo nao existe, sem permissao, etc.
        }

        if (!ok) {
            sessoes.clear();       // se deu erro, nao deixa dados pela metade
        }

        // Monta a lista que a tabela usa: copia os valores do mapa e ordena pelo numero
        linhas = new ArrayList<>(sessoes.values());
        linhas.sort(Comparator.comparing((Sessao s) -> s.numeroCelular));

        fireTableDataChanged();    // avisa a JTable: "os dados mudaram, redesenhe!"
        return ok;
    }

    /**
     * Procura um numero no HashMap. Retorna null se nao existir.
     * GET e O(1): calcula o hash da chave, vai direto ao bucket certo.
     */
    public Sessao pesquisar(String numeroCelular) {
        return sessoes.get(numeroCelular);
    }

    // ===================== metodos exigidos pela JTable =====================

    // Quantas linhas a tabela tem
    @Override
    public int getRowCount() {
        return linhas.size();
    }

    // Quantas colunas: 1 (numero) + 1 para cada campo do JSON
    @Override
    public int getColumnCount() {
        return CAMPOS.length + 1;
    }

    // Titulo de cada coluna
    @Override
    public String getColumnName(int coluna) {
        return coluna == 0 ? "numero_celular" : CAMPOS[coluna - 1];
    }

    // O que aparece na celula (linha, coluna). A JTable chama isso para cada celula.
    @Override
    public Object getValueAt(int linha, int coluna) {
        Sessao s = linhas.get(linha);
        if (coluna == 0) {
            return s.numeroCelular;                  // coluna 0 = o numero
        }
        // Demais colunas: aplica a regex do campo sobre o JSON e devolve o valor achado
        Matcher m = PADROES[coluna - 1].matcher(s.dadosSessao);
        return m.find() ? m.group(1) : "";
    }
}
