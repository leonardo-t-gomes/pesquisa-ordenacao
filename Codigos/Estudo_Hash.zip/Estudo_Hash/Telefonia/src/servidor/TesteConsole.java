package servidor;

import servidor.model.Sessao;
import servidor.model.TabelaHash;

/**
 * Teste SEM tela. Troque o caminho abaixo pelo do seu telephony_sessions.txt.
 */
public class TesteConsole {
    public static void main(String[] args) {
        String arquivo = args.length > 0 ? args[0] : "telephony_sessions.txt";

        TabelaHash tabela = new TabelaHash();
        boolean ok = tabela.carregar(arquivo);
        System.out.println("Carregou? " + ok + "  | total: " + tabela.sessoes.size());

        Sessao s = tabela.pesquisar("5592914942603");          // GET no HashMap
        System.out.println(s == null ? "Nao achou" : "Achou: " + s.numeroCelular);

        System.out.println("Existe 000? " + tabela.sessoes.containsKey("000"));  // false
    }
}
