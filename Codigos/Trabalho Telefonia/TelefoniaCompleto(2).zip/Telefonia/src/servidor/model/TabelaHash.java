package servidor.model;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.AbstractTableModel;

/**
 * Model: guarda as sessões em um HashMap (chave = número do celular) e também
 * serve de modelo de dados para a JTable da tela.
 */
public class TabelaHash extends AbstractTableModel {

    public HashMap<String, Sessao> sessoes = new HashMap<>();

    /** Cópia ordenada das sessões, só para exibir na tabela. */
    private List<Sessao> linhas = new ArrayList<>();

    // colunas da tabela: o número do celular + cada campo do JSON da sessão
    private static final String[] CAMPOS = {
        "session_id", "imsi", "imei", "mcc", "mnc", "cell_id", "lac", "bearer",
        "start_time", "end_time", "duration_s", "ip_addr", "sip_call_id", "codec",
        "bytes_up", "bytes_down", "lat", "lon", "encryption"
    };
    private static final Pattern[] PADROES = new Pattern[CAMPOS.length];
    static {
        for (int i = 0; i < CAMPOS.length; i++) {
            PADROES[i] = Pattern.compile("\"" + CAMPOS[i] + "\"\\s*:\\s*\"?([^\",}]*)\"?");
        }
    }

    /**
     * Lê o arquivo (uma sessão por linha, no formato numeroCelular;dadosSessao),
     * cria um objeto Sessao para cada linha e coloca no HashMap.
     *
     * @return true se leu tudo; false se o arquivo não existe ou tem linha inválida
     */
    public boolean carregar(String nomeArquivo) {
        sessoes.clear();
        boolean ok = true;

        try (BufferedReader leitor = Files.newBufferedReader(
                Paths.get(nomeArquivo), StandardCharsets.UTF_8)) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                if (linha.isBlank()) {
                    continue;
                }
                String[] partes = linha.split(";", 2); // só separa no primeiro ';'
                if (partes.length < 2) {
                    ok = false;
                    break;
                }
                Sessao sessao = new Sessao(partes[0].trim(), partes[1].trim());
                sessoes.put(sessao.numeroCelular, sessao);
            }
        } catch (IOException | RuntimeException e) {
            ok = false;
        }

        if (!ok) {
            sessoes.clear();
        }
        linhas = new ArrayList<>(sessoes.values());
        linhas.sort(Comparator.comparing((Sessao s) -> s.numeroCelular));
        fireTableDataChanged();
        return ok;
    }

    /** Procura um número no HashMap. Retorna null se não existir. */
    public Sessao pesquisar(String numeroCelular) {
        return sessoes.get(numeroCelular);
    }

    // ------------------------------------------------ métodos da JTable

    @Override
    public int getRowCount() {
        return linhas.size();
    }

    @Override
    public int getColumnCount() {
        return CAMPOS.length + 1;
    }

    @Override
    public String getColumnName(int coluna) {
        return coluna == 0 ? "numero_celular" : CAMPOS[coluna - 1];
    }

    @Override
    public Object getValueAt(int linha, int coluna) {
        Sessao s = linhas.get(linha);
        if (coluna == 0) {
            return s.numeroCelular;
        }
        Matcher m = PADROES[coluna - 1].matcher(s.dadosSessao);
        return m.find() ? m.group(1) : "";
    }
}
