package servidor.controller;

import servidor.model.Sessao;
import servidor.model.TabelaHash;

/**
 * Controller: recebe as ações da view e opera sobre o model (TabelaHash).
 */
public class ServidorController {

    private final TabelaHash tabela = new TabelaHash();

    /** Model da JTable, para a view se ligar a ele. */
    public TabelaHash getTabela() {
        return tabela;
    }

    public boolean carregarArquivo(String nomeArquivo) {
        return tabela.carregar(nomeArquivo);
    }

    public int totalSessoes() {
        return tabela.sessoes.size();
    }

    /** Retorna a sessão do número (busca no HashMap) ou null se não existir. */
    public Sessao pesquisar(String numeroCelular) {
        return tabela.pesquisar(numeroCelular.trim());
    }
}
