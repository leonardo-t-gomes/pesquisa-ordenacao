package servidor.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;
import servidor.controller.ServidorController;
import servidor.model.Sessao;
import servidor.model.TabelaHash;

/**
 * View: janela única com o campo do arquivo, a tabela com todos os números e
 * o campo de consulta. A consulta filtra as linhas da própria tabela.
 */
public class JFrameServidor extends JFrame {

    private final ServidorController controller = new ServidorController();

    private final JTextField txtArquivo = new JTextField(40);
    private final JButton btnCarregar = new JButton("Carregar");
    private final JTable tabela = new JTable(controller.getTabela());
    private final TableRowSorter<TabelaHash> sorter = new TableRowSorter<>(controller.getTabela());
    private final JTextField txtNumero = new JTextField(16);
    private final JButton btnConsultar = new JButton("Consultar");
    private final JLabel lblStatus = new JLabel("Nenhum arquivo carregado.");

    public JFrameServidor() {
        setTitle("Servidor de Sessões em Telefonia");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel raiz = new JPanel(new BorderLayout(8, 8));
        raiz.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(raiz);

        // topo: caminho completo do arquivo
        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        topo.add(new JLabel("Arquivo da base de dados:"));
        topo.add(txtArquivo);
        topo.add(btnCarregar);
        add(topo, BorderLayout.NORTH);

        // centro: tabela (com ordenação/filtro e barra de rolagem horizontal)
        tabela.setRowSorter(sorter);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        for (int i = 0; i < tabela.getColumnCount(); i++) {
            tabela.getColumnModel().getColumn(i).setPreferredWidth(i == 0 ? 120 : (i == 1 ? 280 : 130));
        }
        JScrollPane rolagem = new JScrollPane(tabela);
        rolagem.setPreferredSize(new Dimension(900, 400));
        add(rolagem, BorderLayout.CENTER);

        // embaixo: consulta + status
        JPanel sul = new JPanel(new BorderLayout(0, 6));
        JPanel consulta = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        consulta.add(new JLabel("Número do celular:"));
        consulta.add(txtNumero);
        consulta.add(btnConsultar);
        sul.add(consulta, BorderLayout.NORTH);
        sul.add(lblStatus, BorderLayout.SOUTH);
        add(sul, BorderLayout.SOUTH);

        btnCarregar.addActionListener(e -> carregar());
        txtArquivo.addActionListener(e -> carregar());
        btnConsultar.addActionListener(e -> consultar());
        txtNumero.addActionListener(e -> consultar());

        pack();
        setLocationRelativeTo(null);
    }

    private void carregar() {
        String arquivo = txtArquivo.getText().trim();
        if (arquivo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Digite o caminho completo do arquivo.");
            return;
        }
        sorter.setRowFilter(null); // tira filtro anterior
        if (controller.carregarArquivo(arquivo)) {
            lblStatus.setText(controller.totalSessoes() + " sessões carregadas.");
        } else {
            lblStatus.setText("Falha ao carregar o arquivo.");
            JOptionPane.showMessageDialog(this, "Arquivo não localizado ou com problemas");
        }
    }

    /** Filtra a tabela para mostrar só o número consultado (campo vazio mostra todos). */
    private void consultar() {
        final String numero = txtNumero.getText().trim();
        if (numero.isEmpty()) {
            sorter.setRowFilter(null);
            lblStatus.setText("Exibindo todas as " + controller.totalSessoes() + " sessões.");
            return;
        }

        Sessao sessao = controller.pesquisar(numero); // busca no HashMap
        sorter.setRowFilter(new RowFilter<TabelaHash, Integer>() {
            @Override
            public boolean include(Entry<? extends TabelaHash, ? extends Integer> linha) {
                return numero.equals(linha.getStringValue(0));
            }
        });
        lblStatus.setText(sessao == null
                ? "Número " + numero + " não encontrado."
                : "Número " + numero + " encontrado.");
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrameServidor.class.getName())
                    .log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new JFrameServidor().setVisible(true));
    }
}
