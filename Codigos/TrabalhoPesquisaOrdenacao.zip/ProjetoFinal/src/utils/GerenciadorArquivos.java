package utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import model.Produto;


public class GerenciadorArquivos {

    private static final String CABECALHO = "id;nome;categoria;preco;estoque";

    public static ArrayList<Produto> lerArquivo(File arquivo) throws IOException {
        ArrayList<Produto> lista = new ArrayList<>();

        try (BufferedReader br = Files.newBufferedReader(arquivo.toPath(), StandardCharsets.UTF_8)) {
            br.readLine();

            String linha;
            int numLinha = 1;
            while ((linha = br.readLine()) != null) {
                numLinha++;
                if (linha.trim().isEmpty()) {
                    continue;
                }
                try {
                    String[] d = linha.split(";");
                    int id = Integer.parseInt(d[0].trim());
                    String nome = d[1].trim();
                    String categoria = d[2].trim();
                    double preco = Double.parseDouble(d[3].trim().replace(",", "."));
                    int estoque = Integer.parseInt(d[4].trim());
                    lista.add(new Produto(id, nome, categoria, preco, estoque));
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    throw new IOException("Linha " + numLinha + " inválida: " + linha, e);
                }
            }
        }
        return lista;
    }

    public static void exportarArquivo(List<Produto> lista, File arquivo) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(arquivo.toPath(), StandardCharsets.UTF_8)) {
            bw.write(CABECALHO);
            bw.newLine();
            for (Produto p : lista) {
                bw.write(String.format(Locale.US, "%d;%s;%s;%.2f;%d",
                        p.getId(), p.getNome(), p.getCategoria(), p.getPreco(), p.getEstoque()));
                bw.newLine();
            }
        }
    }
}
