package utils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import model.Produto;


public class Ordenador {

    public static Comparator<Produto> porNome() {
        return (p1, p2) -> p1.getNome().compareToIgnoreCase(p2.getNome());
    }

    public static Comparator<Produto> porPreco() {
        return (p1, p2) -> Double.compare(p1.getPreco(), p2.getPreco());
    }

    public static Comparator<Produto> porId() {
        return (p1, p2) -> Integer.compare(p1.getId(), p2.getId());
    }


    public static long bubbleSort(List<Produto> lista, Comparator<Produto> comp) {
        long inicio = System.nanoTime();

        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            boolean houveTroca = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (comp.compare(lista.get(j), lista.get(j + 1)) > 0) {
                    trocar(lista, j, j + 1);
                    houveTroca = true;
                }
            }
            if (!houveTroca) {
                break; 
            }
        }

        return System.nanoTime() - inicio;
    }


    public static long quickSort(List<Produto> lista, Comparator<Produto> comp) {
        long inicio = System.nanoTime();

        if (lista != null && lista.size() > 1) {
            quickSort(lista, 0, lista.size() - 1, comp);
        }

        return System.nanoTime() - inicio;
    }

    private static void quickSort(List<Produto> lista, int ini, int fim, Comparator<Produto> comp) {
        while (ini < fim) {
            int p = particionar(lista, ini, fim, comp);
            if (p - ini < fim - p) {
                quickSort(lista, ini, p - 1, comp);
                ini = p + 1;
            } else {
                quickSort(lista, p + 1, fim, comp);
                fim = p - 1;
            }
        }
    }

    private static int particionar(List<Produto> lista, int ini, int fim, Comparator<Produto> comp) {
        int meio = ini + (fim - ini) / 2;
        trocar(lista, meio, fim);
        Produto pivo = lista.get(fim);

        int i = ini - 1;
        for (int j = ini; j < fim; j++) {
            if (comp.compare(lista.get(j), pivo) <= 0) {
                i++;
                trocar(lista, i, j);
            }
        }
        trocar(lista, i + 1, fim);
        return i + 1;
    }


    public static long listSortReferencia(List<Produto> lista, Comparator<Produto> comp) {
        long inicio = System.nanoTime();
        lista.sort(comp);
        return System.nanoTime() - inicio;
    }


    private static void trocar(List<Produto> lista, int i, int j) {
        Produto tmp = lista.get(i);
        lista.set(i, lista.get(j));
        lista.set(j, tmp);
    }

    public static boolean estaOrdenada(List<Produto> lista, Comparator<Produto> comp) {
        for (int i = 1; i < lista.size(); i++) {
            if (comp.compare(lista.get(i - 1), lista.get(i)) > 0) {
                return false;
            }
        }
        return true;
    }
}
