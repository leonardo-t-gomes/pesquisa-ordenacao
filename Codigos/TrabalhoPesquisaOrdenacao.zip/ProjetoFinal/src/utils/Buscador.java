package utils;

import java.util.ArrayList;
import java.util.List;
import model.Produto;
import model.TabelaHash;

public class Buscador {

    public interface BuscaPorId {
        Produto buscar(int id);
    }

    public static Produto buscaLinearPorId(List<Produto> lista, int id) {
        for (int i = 0; i < lista.size(); i++) {
            Produto p = lista.get(i);
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    public static Produto buscaBinariaPorId(List<Produto> listaOrdenadaPorId, int id) {
        int ini = 0;
        int fim = listaOrdenadaPorId.size() - 1;

        while (ini <= fim) {
            int meio = ini + (fim - ini) / 2;
            Produto p = listaOrdenadaPorId.get(meio);

            if (p.getId() == id) {
                return p;
            } else if (p.getId() < id) {
                ini = meio + 1;
            } else {
                fim = meio - 1;
            }
        }
        return null;
    }

    public static Produto buscaHashPorId(TabelaHash tabela, int id) {
        return tabela.buscarPorId(id);
    }

    public static List<Produto> buscaHashPorCategoria(TabelaHash tabela, String categoria) {
        return tabela.buscarPorCategoria(categoria);
    }

    public static List<Produto> buscaLinearPorCategoria(List<Produto> lista, String categoria) {
        List<Produto> resultado = new ArrayList<>();
        for (Produto p : lista) {
            if (p.getCategoria().equalsIgnoreCase(categoria)) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    public static double tempoMedioNs(BuscaPorId busca, int[] ids, int repeticoes) {
        long achados = 0;
        long inicio = System.nanoTime();

        for (int i = 0; i < repeticoes; i++) {
            Produto p = busca.buscar(ids[i % ids.length]);
            if (p != null) {
                achados++;
            }
        }

        long total = System.nanoTime() - inicio;
        if (achados < 0) {
            System.out.println(achados); 
        }
        return (double) total / repeticoes;
    }

    public static double tempoMedioCategoriaNs(java.util.function.Function<String, List<Produto>> busca,
                                               String categoria, int repeticoes) {
        long total = 0;
        long inicio = System.nanoTime();
        for (int i = 0; i < repeticoes; i++) {
            total += busca.apply(categoria).size(); 
        }
        long fim = System.nanoTime();
        if (total < 0) {
            System.out.println(total);
        }
        return (double) (fim - inicio) / repeticoes;
    }

    public static int[] sortearIds(List<Produto> lista, int n) {
        java.util.Random rnd = new java.util.Random(42);
        int[] ids = new int[n];
        for (int i = 0; i < n; i++) {
            ids[i] = lista.get(rnd.nextInt(lista.size())).getId();
        }
        return ids;
    }
}
