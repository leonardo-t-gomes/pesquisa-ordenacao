/*
 * Autor(es): <SEU NOME> - Turma: <SUA TURMA>
 *
 * Trabalho Prático - Pesquisa e Ordenação (UFN)
 * Catálogo de produtos: comparando ordenação e busca.
 *
 * Execute com a pasta do projeto como diretório de trabalho (os arquivos
 * produtos_*.txt ficam na raiz do projeto).
 */
package projetofinal;

public class ProjetoFinal {

    public static void main(String[] args) {
        view.JFrame.main(args);   // abre a interface Swing
    }
}
