/*
 * Teste em modo console (sem interface) das etapas 3.1 a 3.3.
 *
 * Trabalho Prático - Pesquisa e Ordenação (UFN)
 * Etapas 3.1 a 3.3 (a interface Swing e o relatório entram nas próximas etapas).
 * Execute com a pasta do projeto como diretório de trabalho (os arquivos
 * produtos_*.txt ficam na raiz do projeto).
 */
package projetofinal;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import model.Produto;
import model.TabelaHash;
import utils.Buscador;
import utils.GerenciadorArquivos;
import utils.Ordenador;

public class TesteConsole {

    private static final int REPETICOES = 1000;

    public static void main(String[] args) throws Exception {
        int[] tamanhos = {1000, 10000, 50000};

        for (int n : tamanhos) {
            File arq = new File("produtos_" + n + ".txt");
            System.out.println("=== " + arq.getName() + " ===");

            // 3.1 leitura
            ArrayList<Produto> original = GerenciadorArquivos.lerArquivo(arq);
            System.out.println("Lidos: " + original.size() + " produtos");

            // 3.2 ordenação por preço (cópias, para medir cada algoritmo na mesma entrada)
            ArrayList<Produto> c1 = new ArrayList<>(original);
            ArrayList<Produto> c2 = new ArrayList<>(original);
            ArrayList<Produto> c3 = new ArrayList<>(original);
            System.out.printf("Bubble Sort (preço):  %10.3f ms  ok=%b%n",
                    Ordenador.bubbleSort(c1, Ordenador.porPreco()) / 1e6,
                    Ordenador.estaOrdenada(c1, Ordenador.porPreco()));
            System.out.printf("Quick Sort  (preço):  %10.3f ms  ok=%b%n",
                    Ordenador.quickSort(c2, Ordenador.porPreco()) / 1e6,
                    Ordenador.estaOrdenada(c2, Ordenador.porPreco()));
            System.out.printf("List.sort ref(preço): %10.3f ms%n",
                    Ordenador.listSortReferencia(c3, Ordenador.porPreco()) / 1e6);

            ArrayList<Produto> porNome = new ArrayList<>(original);
            Ordenador.quickSort(porNome, Ordenador.porNome());
            System.out.println("Quick Sort por nome ok=" + Ordenador.estaOrdenada(porNome, Ordenador.porNome()));

            // 3.3 busca por id
            ArrayList<Produto> porId = new ArrayList<>(original);
            Ordenador.quickSort(porId, Ordenador.porId());   // pré-requisito da busca binária
            TabelaHash tabela = new TabelaHash(original);
            System.out.printf("Construção HashMap:   %10.3f ms%n", tabela.getTempoConstrucaoNs() / 1e6);

            int[] ids = Buscador.sortearIds(original, REPETICOES);
            System.out.printf("Busca linear (média): %10.1f ns%n",
                    Buscador.tempoMedioNs(id -> Buscador.buscaLinearPorId(original, id), ids, REPETICOES));
            System.out.printf("Busca binária(média): %10.1f ns%n",
                    Buscador.tempoMedioNs(id -> Buscador.buscaBinariaPorId(porId, id), ids, REPETICOES));
            System.out.printf("Busca HashMap(média): %10.1f ns%n",
                    Buscador.tempoMedioNs(id -> Buscador.buscaHashPorId(tabela, id), ids, REPETICOES));

            // categoria
            List<Produto> cat = Buscador.buscaHashPorCategoria(tabela, "Esportes");
            System.out.println("Categoria 'Esportes': " + cat.size() + " produtos");

            System.out.println();
        }
    }
}
