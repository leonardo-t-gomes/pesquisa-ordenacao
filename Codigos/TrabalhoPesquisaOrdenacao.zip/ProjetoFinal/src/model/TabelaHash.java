package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;


public class TabelaHash {

    private final HashMap<Integer, Produto> porId = new HashMap<>();
    private final HashMap<String, List<Produto>> porCategoria = new HashMap<>();
    private long tempoConstrucaoNs;

    public TabelaHash(List<Produto> produtos) {
        long inicio = System.nanoTime();

        for (Produto p : produtos) {
            porId.put(p.getId(), p);
            porCategoria.computeIfAbsent(chave(p.getCategoria()), k -> new ArrayList<>()).add(p);
        }

        tempoConstrucaoNs = System.nanoTime() - inicio;
    }

    private static String chave(String categoria) {
        return categoria.trim().toLowerCase(Locale.ROOT);
    }

    public Produto buscarPorId(int id) {
        return porId.get(id);
    }

    public List<Produto> buscarPorCategoria(String categoria) {
        List<Produto> lista = porCategoria.get(chave(categoria));
        return lista == null ? new ArrayList<>() : lista;
    }

    public long getTempoConstrucaoNs() {
        return tempoConstrucaoNs;
    }
}
