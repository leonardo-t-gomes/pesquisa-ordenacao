/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.table.AbstractTableModel;
import model.Produto;
import model.TabelaHash;
import utils.Buscador;
import utils.GerenciadorArquivos;
import utils.Ordenador;

/**
 *
 * @author User
 */
public class JFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JFrame.class.getName());

    /**
     * Creates new form JFrame
     */
    public JFrame() {
        initComponents();
        tblProdutos.setModel(modelo);
    }


    private static final int REPETICOES = 1000;

    private static final String[] OPCOES_ORDENACAO = {
        "Ordenar...",
        "QuickSort por Nome", "QuickSort por Preço", "QuickSort por Id",
        "Bubble por Nome", "Bubble por Preço", "Bubble por Id"
    };
    private static final String[] OPCOES_PESQUISA = {
        "Busca Linear por Id", "Busca Binária por Id", "HashMap por Id",
        "Busca Linear por Categoria", "HashMap por Categoria"
    };

    private ArrayList<Produto> lista = new ArrayList<>();   // todos, na ordem atual
    private TabelaHash tabela = new TabelaHash(lista);
    private final ProdutoTableModel modelo = new ProdutoTableModel();
    private boolean atualizandoCombo = false;


    private void corrigirLayout() {
        javax.swing.GroupLayout ly = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(ly);
        ly.setAutoCreateGaps(true);
        ly.setAutoCreateContainerGaps(true);

        ly.setHorizontalGroup(ly.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ly.createSequentialGroup()
                .addGroup(ly.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4))
                .addGroup(ly.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ly.createSequentialGroup()
                        .addComponent(txtArquivo, 100, 400, Short.MAX_VALUE)
                        .addComponent(btnBuscar))
                    .addComponent(cmbOrdenacao, 100, 300, Short.MAX_VALUE)
                    .addComponent(cmbPesquisa, 100, 300, Short.MAX_VALUE)
                    .addComponent(txtConsultar, 100, 300, Short.MAX_VALUE)
                    .addComponent(lblUltimaOperacao, 100, 300, Short.MAX_VALUE)))
            .addComponent(jScrollPane1, 0, 700, Short.MAX_VALUE));

        ly.setVerticalGroup(ly.createSequentialGroup()
            .addGroup(ly.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel1).addComponent(txtArquivo).addComponent(btnBuscar))
            .addGroup(ly.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel2).addComponent(cmbOrdenacao))
            .addGroup(ly.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel3).addComponent(cmbPesquisa))
            .addGroup(ly.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel5).addComponent(txtConsultar))
            .addGroup(ly.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel4).addComponent(lblUltimaOperacao))
            .addComponent(jScrollPane1, 150, 337, Short.MAX_VALUE));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblProdutos = new javax.swing.JTable();
        btnBuscar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtArquivo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cmbOrdenacao = new javax.swing.JComboBox<>();
        cmbPesquisa = new javax.swing.JComboBox<>();
        lblUltimaOperacao = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtConsultar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tblProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Categoria", "Preço", "Estoque"
            }
        ));
        jScrollPane1.setViewportView(tblProdutos);

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);

        jLabel1.setText("Arquivo");

        jLabel2.setText("Ordenar usando:");

        jLabel3.setText("Pesquisar usando:");

        cmbOrdenacao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "QuickSort", "Bubble", " ", " " }));

        cmbPesquisa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Busca Linear", "Busca Binaria", " " }));
        cmbPesquisa.setToolTipText("");

        lblUltimaOperacao.setText(".....");

        jLabel4.setText("Ultima Operação:");

        jLabel5.setText("Consultar:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblUltimaOperacao))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(58, 58, 58)
                                        .addComponent(txtArquivo, javax.swing.GroupLayout.PREFERRED_SIZE, 444, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBuscar))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(cmbOrdenacao, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(cmbPesquisa, 0, 306, Short.MAX_VALUE)
                                        .addComponent(txtConsultar)))))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBuscar)
                    .addComponent(jLabel1)
                    .addComponent(txtArquivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbOrdenacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUltimaOperacao)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(txtConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>                        

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        escolherArquivo();
    }                                         


    private void escolherArquivo() {
        String nome = txtArquivo.getText().trim();
        if (nome.isEmpty()) {
            aviso("Digite o caminho completo do arquivo.");
            return;
        }
        File arquivo = new File(nome);
        if (!arquivo.exists()) {
            aviso("Arquivo não encontrado:\n" + nome);
            return;
        }
        carregar(arquivo);
    }

    private void carregar(File arquivo) {
        try {
            long ini = System.nanoTime();
            ArrayList<Produto> lidos = GerenciadorArquivos.lerArquivo(arquivo);
            long tLeitura = System.nanoTime() - ini;

            lista = lidos;
            tabela = new TabelaHash(lista);
            txtArquivo.setText(arquivo.getPath());

            // Atualiza os dados e força o redesenho na thread do Swing
            java.awt.EventQueue.invokeLater(() -> {
                modelo.setDados(lista);
                tblProdutos.revalidate();
                tblProdutos.repaint();
            });

            Set<String> categorias = new LinkedHashSet<>();
            for (Produto p : lista) {
                categorias.add(p.getCategoria());
            }
            txtConsultar.setToolTipText("Id ou categoria + Enter. Categorias: " + String.join(", ", categorias));

            status(lista.size() + " lidos em " + formatar(tLeitura)
                    + " | HashMap: " + formatar(tabela.getTempoConstrucaoNs()));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao ler o arquivo:\n" + ex.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportar() {
        if (lista.isEmpty()) {
            aviso("Nenhum dado carregado.");
            return;
        }
        JFileChooser fc = new JFileChooser(new File(System.getProperty("user.dir")));
        fc.setSelectedFile(new File("produtos_exportados.txt"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        try {
            GerenciadorArquivos.exportarArquivo(lista, fc.getSelectedFile());
            status(lista.size() + " exportados para " + fc.getSelectedFile().getName());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao gravar o arquivo:\n" + ex.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ordenar(int opcao) {
        if (lista.isEmpty()) {
            aviso("Carregue um arquivo primeiro.");
            voltarComboOrdenacao();
            return;
        }

        final boolean bubble = opcao >= 4;
        final int campo = (opcao - 1) % 3;
        final String descricao = OPCOES_ORDENACAO[opcao];
        final Comparator<Produto> comp = campo == 0 ? Ordenador.porNome()
                : campo == 1 ? Ordenador.porPreco() : Ordenador.porId();


        final ArrayList<Produto> copia = new ArrayList<>(lista);
        definirOcupado(true);
        status("Ordenando (" + descricao + ")...");

        new SwingWorker<Long, Void>() {
            @Override
            protected Long doInBackground() {
                return bubble ? Ordenador.bubbleSort(copia, comp)
                              : Ordenador.quickSort(copia, comp);
            }

            @Override
            protected void done() {
                try {
                    long ns = get();
                    lista = copia;
                    modelo.setDados(lista);
                    status(descricao + ": " + formatar(ns));
                } catch (Exception ex) {
                    status("Erro na ordenação: " + ex);
                } finally {
                    definirOcupado(false);
                    voltarComboOrdenacao();
                }
            }
        }.execute();
    }

    private void voltarComboOrdenacao() {
        atualizandoCombo = true;
        cmbOrdenacao.setSelectedIndex(0);
        atualizandoCombo = false;
    }

    private void definirOcupado(boolean ocupado) {
        btnBuscar.setEnabled(!ocupado);
        cmbOrdenacao.setEnabled(!ocupado);
        cmbPesquisa.setEnabled(!ocupado);
        txtConsultar.setEnabled(!ocupado);
    }

    private void consultar() {
        if (lista.isEmpty()) {
            aviso("Carregue um arquivo primeiro.");
            return;
        }
        String texto = txtConsultar.getText().trim();
        if (texto.isEmpty()) {
            aviso("Digite o id ou a categoria a consultar.");
            return;
        }
        if (cmbPesquisa.getSelectedIndex() <= 2) {
            consultarPorId(texto);
        } else {
            consultarPorCategoria(texto);
        }
    }

    private void consultarPorId(String texto) {
        final int id;
        try {
            id = Integer.parseInt(texto);
        } catch (NumberFormatException ex) {
            aviso("Para esta busca, digite um id (número inteiro).");
            return;
        }

        final int tecnica = cmbPesquisa.getSelectedIndex();
        final ArrayList<Produto> base = lista;
        final TabelaHash hash = tabela;
        final Buscador.BuscaPorId busca;

        if (tecnica == 0) {
            busca = x -> Buscador.buscaLinearPorId(base, x);
        } else if (tecnica == 1) {
            if (!Ordenador.estaOrdenada(base, Ordenador.porId())) {
                aviso("A busca binária exige a lista ordenada por Id.\n"
                        + "Use \"Ordenar usando\" > \"... por Id\" e tente de novo.");
                return;
            }
            busca = x -> Buscador.buscaBinariaPorId(base, x);
        } else {
            busca = x -> Buscador.buscaHashPorId(hash, x);
        }

        Produto achado = busca.buscar(id);
        double media = Buscador.tempoMedioNs(busca, new int[]{id}, REPETICOES);

        List<Produto> resultado = new ArrayList<>();
        if (achado != null) {
            resultado.add(achado);
        }
        modelo.setDados(resultado);
        status(OPCOES_PESQUISA[tecnica] + " " + id + ": "
                + (achado != null ? "achou" : "não achou")
                + " | média " + formatar(media) + " (x" + REPETICOES + ")");
    }

    private void consultarPorCategoria(String categoria) {
        final int tecnica = cmbPesquisa.getSelectedIndex();
        final ArrayList<Produto> base = lista;
        final TabelaHash hash = tabela;
        final java.util.function.Function<String, List<Produto>> busca = tecnica == 3
                ? c -> Buscador.buscaLinearPorCategoria(base, c)
                : c -> Buscador.buscaHashPorCategoria(hash, c);

        List<Produto> resultado = busca.apply(categoria);
        double media = Buscador.tempoMedioCategoriaNs(busca, categoria, REPETICOES);

        modelo.setDados(resultado);
        status(OPCOES_PESQUISA[tecnica] + " \"" + categoria + "\": " + resultado.size()
                + " itens | média " + formatar(media) + " (x" + REPETICOES + ")");
    }


    private void status(String texto) {
        lblUltimaOperacao.setText(texto);
        lblUltimaOperacao.setToolTipText(texto);
    }

    private void aviso(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Atenção", JOptionPane.WARNING_MESSAGE);
    }

    private static String formatar(double ns) {
        if (ns < 1_000) {
            return String.format("%.0f ns", ns);
        } else if (ns < 1_000_000) {
            return String.format("%.2f µs", ns / 1_000);
        } else if (ns < 1_000_000_000) {
            return String.format("%.3f ms", ns / 1_000_000);
        }
        return String.format("%.2f s", ns / 1_000_000_000);
    }

    /** Modelo da JTable: mostra uma List<Produto> sem copiá-la. */
    private static class ProdutoTableModel extends AbstractTableModel {

        private static final String[] COLUNAS = {"ID", "Nome", "Categoria", "Preço", "Estoque"};
        private List<Produto> dados = new ArrayList<>();

        void setDados(List<Produto> novos) {
            this.dados = novos;
            fireTableDataChanged();
        }

        @Override public int getRowCount() { return dados.size(); }
        @Override public int getColumnCount() { return COLUNAS.length; }
        @Override public String getColumnName(int c) { return COLUNAS[c]; }

        @Override
        public Object getValueAt(int linha, int coluna) {
            Produto p = dados.get(linha);
            switch (coluna) {
                case 0:  return p.getId();
                case 1:  return p.getNome();
                case 2:  return p.getCategoria();
                case 3:  return String.format("%.2f", p.getPreco());
                default: return p.getEstoque();
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new JFrame().setVisible(true));
    }

    private javax.swing.JButton btnBuscar;
    private javax.swing.JComboBox<String> cmbOrdenacao;
    private javax.swing.JComboBox<String> cmbPesquisa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblUltimaOperacao;
    private javax.swing.JTable tblProdutos;
    private javax.swing.JTextField txtArquivo;
    private javax.swing.JTextField txtConsultar;
    // End of variables declaration                   
}
