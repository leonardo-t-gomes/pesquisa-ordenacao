/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import model.Produto;

/**
 *
 * @author laboratorio
 */
public class Utilidades {
    
    public static ArrayList<Produto> lerArquivo(File arquivoEscolhido) {
        ArrayList<Produto> listaProdutos = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(arquivoEscolhido))) {
            
            String linha = br.readLine(); 

            while ((linha = br.readLine()) != null) {
                if (linha.trim().isEmpty()) {
                    continue;
                }

                String[] dados = linha.split(";");

                int id = Integer.parseInt(dados[0].trim());
                String nome = dados[1].trim();
                int categoria = Integer.parseInt(dados[2].trim());
                double preco = Double.parseDouble(dados[3].trim().replace(",", "."));
                int quantidade = Integer.parseInt(dados[4].trim());

                Produto p = new Produto(id,nome,categoria, preco, quantidade);
                listaProdutos.add(p);
            }

        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            System.err.println("Erro de formatação nos dados do arquivo: " + e.getMessage());
        }

        return listaProdutos;
    }

    public static Comparator<Produto> porNome() {
        return new Comparator<Produto>() {
            @Override
            public int compare(Produto p1, Produto p2) {
                return p1.getNome().compareToIgnoreCase(p2.getNome());
            }
        };
    }

    public static Comparator<Produto> porPreco() {
        return new Comparator<Produto>() {
            @Override
            public int compare(Produto p1, Produto p2) {
                return Double.compare(p1.getPreco(), p2.getPreco());
            }
        };
    }

    public static long bubbleSort(ArrayList<Produto> lista, Comparator<Produto> comparador) {
        long inicio = System.nanoTime();

        int n = lista.size();
        boolean houveTroca;

        for (int i = 0; i < n - 1; i++) {
            houveTroca = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (comparador.compare(lista.get(j), lista.get(j + 1)) > 0) {
                    Produto temp = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, temp);
                    houveTroca = true;
                }
            }
            if (!houveTroca) {
                break;
            }
        }

        long fim = System.nanoTime();
        return fim - inicio;
    }


    public static long quickSort(ArrayList<Produto> lista, Comparator<Produto> comparador) {
        long inicio = System.nanoTime();

        if (lista != null && lista.size() > 1) {
            quickSortRecursivo(lista, 0, lista.size() - 1, comparador);
        }

        long fim = System.nanoTime();
        return fim - inicio;
    }

    private static void quickSortRecursivo(ArrayList<Produto> lista, int inicio, int fim, Comparator<Produto> comparador) {
        if (inicio < fim) {
            int indicePivo = particionar(lista, inicio, fim, comparador);
            quickSortRecursivo(lista, inicio, indicePivo - 1, comparador);
            quickSortRecursivo(lista, indicePivo + 1, fim, comparador);
        }
    }

    private static int particionar(ArrayList<Produto> lista, int inicio, int fim, Comparator<Produto> comparador) {
        Produto pivo = lista.get(fim);
        int i = inicio - 1;

        for (int j = inicio; j < fim; j++) {
            if (comparador.compare(lista.get(j), pivo) <= 0) {
                i++;
                trocar(lista, i, j);
            }
        }

        trocar(lista, i + 1, fim);
        return i + 1;
    }

    private static void trocar(ArrayList<Produto> lista, int i, int j) {
        Produto temp = lista.get(i);
        lista.set(i, lista.get(j));
        lista.set(j, temp);
    }
    
    public static <Produto> int buscaLinear(List<Produto> lista, Produto alvo) {
            for (int i = 0; i < lista.size(); i++) {
                Produto atual = lista.get(i);
                if (atual == null ? alvo == null : atual.equals(alvo)) {
                    return i;
                }
            }
            return -1;
        }
    
    
    public class BuscaBinariaPorId {

        public static class Item {
            private int id;
            private String nome;

            public Item(int id, String nome) {
                this.id = id;
                this.nome = nome;
            }

            public int getId() { return id; }
            public String getNome() { return nome; }
        }

        public static int buscaBinariaPorId(List<Item> listaOrdenada, int idAlvo) {
            int inicio = 0;
            int fim = listaOrdenada.size() - 1;

            while (inicio <= fim) {
                int meio = inicio + (fim - inicio) / 2;
                int idAtual = listaOrdenada.get(meio).getId();

                if (idAtual == idAlvo) {
                    return meio;
                } else if (idAtual < idAlvo) {
                    inicio = meio + 1;
                } else {
                    fim = meio - 1;
                }
            }

            return -1; 
        }
    }
}

